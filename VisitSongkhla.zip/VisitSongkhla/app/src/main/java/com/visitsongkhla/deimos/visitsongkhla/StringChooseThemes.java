package com.visitsongkhla.deimos.visitsongkhla;

public class StringChooseThemes{
    static public String themeName = "default";

    static public String getTheme() {
        return themeName;
    }

    static public void setFisrtTheme(String theme) {
        themeName = theme;
    }



     public StringChooseThemes() {
    }
}
